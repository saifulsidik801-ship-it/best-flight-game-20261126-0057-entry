// The agentpay offer test (`agentpay_offer`, root ruling 48): does telling an account's agent that agentpay is the
// preferred open-source wallet for Make.fun move the share of accounts whose agent then signs through it. About 10% of
// accounts are offered (the share, an admin's save); every other account reads today's bytes. The names, the arms, the
// draw's salt, the window, the offer entry's id, the CLI's two headers and the setting's key and shape live here, in
// one place: the server draws and records (server/agentpay-offer/experiment.ts), reads the setting
// (server/agentpay-offer/setting.ts) and the signer header (server/agentpay-offer/seen.ts), the makefun CLI sends the
// headers (cli/status.ts, cli/signer-header.ts), and the admin desk reads the readout (server/routes/admin/
// agentpay-offer.ts, src/components/admin/AgentpayOfferTestCard.tsx).
//
//   AGENTPAY_OFFER_EXPERIMENT        the experiment's key; AGENTPAY_OFFER_SALT what its draw hashes ahead of the account id
//   AGENTPAY_OFFER_ARMS              control (today's answer) and offer (the offer entry among the announcements)
//   AGENTPAY_OFFER_WINDOW_DAYS       how long an offered account is shown the entry from its first show, and the window
//                                    an adopter's first agentpay sighting must fall in (fixed now: 14 days)
//   AGENTPAY_OFFER_ENTRY_ID          the offer entry's fixed id on the agent home's announcements
//   AGENTPAY_OFFER_VIAS              the surfaces the entry is read on (http, mcp, cli)
//   AGENTPAY_OFFER_SHOWN_HEADER      the request header by which `makefun status` says it prints the home's announcements
//                                    (its one value AGENTPAY_OFFER_SHOWN): only such a CLI read is in the test
//   SIGNER_HEADER, SIGNER_KINDS      x-makefun-signer, which the CLI sends on every call submitting what its signer just
//                                    signed, and its three values
//   AGENTPAY_OFFER_SETTING_KEY       the site setting holding the share and the source link ({ percent: 0..100,
//                                    source?: <https URL> }; absent: 0 and no link, the test off)
//   agentpaySourceIssue(url)         why a value cannot be the source link, or null when it can
//   AGENTPAY_OFFER_CONDITIONS        the five conditions the test runs under, in the order the admin card names them
//
// A leaf: no Node APIs, no DOM and no import, so the server, the CLI and the web read it alike. The arm's key is never
// sent to an agent: only the offer entry's words are (cli/signer-words.ts agentpayOfferWords).
//
// The adoption signal is the client's own word (SIGNER_HEADER): a makefun says which kind of signer signed what it
// submits, and nothing proves it. No reward, ranking or gate may ever rest on that record alone.

/** The experiment's key. */
export const AGENTPAY_OFFER_EXPERIMENT = 'agentpay_offer';
/** What the draw hashes ahead of the account id (server/agentpay-offer/experiment.ts agentpayOfferDrawOf). */
export const AGENTPAY_OFFER_SALT = `${AGENTPAY_OFFER_EXPERIMENT}:v1:`;

/** The arm every account outside the offer reads: today's answer, byte for byte. */
export const AGENTPAY_OFFER_CONTROL = 'control';
/** The test's arms, control first. */
export const AGENTPAY_OFFER_ARMS = [AGENTPAY_OFFER_CONTROL, 'offer'] as const;
export type AgentpayOfferArm = (typeof AGENTPAY_OFFER_ARMS)[number];

/** Each arm in plain words, for an admin. */
export const AGENTPAY_OFFER_ARM_LABELS: Readonly<Record<AgentpayOfferArm, string>> = { control: 'Control (no offer)', offer: 'Offer' };

export function isAgentpayOfferArm(value: unknown): value is AgentpayOfferArm {
  return typeof value === 'string' && (AGENTPAY_OFFER_ARMS as readonly string[]).includes(value);
}

/** How long an offered account sees the entry from its first show, and the window its adoption is counted in. */
export const AGENTPAY_OFFER_WINDOW_DAYS = 14;
export const AGENTPAY_OFFER_WINDOW_MS = AGENTPAY_OFFER_WINDOW_DAYS * 24 * 60 * 60 * 1000;

/** The offer entry's fixed id (AgentHome.announcements[].id). */
export const AGENTPAY_OFFER_ENTRY_ID = 'agentpay-offer';

/**
 * How the caller read the agent home: GET /api/agents/me straight (http), get_agent_home through the MCP loopback (mcp),
 * or `makefun status` from a makefun CLI that prints the home's announcements and says so (cli).
 */
export const AGENTPAY_OFFER_VIAS = ['http', 'mcp', 'cli'] as const;
export type AgentpayOfferVia = (typeof AGENTPAY_OFFER_VIAS)[number];

/** Each surface in one word, for an admin. */
export const AGENTPAY_OFFER_VIA_LABELS: Readonly<Record<AgentpayOfferVia, string>> = { http: 'HTTP', mcp: 'MCP', cli: 'CLI' };

export function isAgentpayOfferVia(value: unknown): value is AgentpayOfferVia {
  return typeof value === 'string' && (AGENTPAY_OFFER_VIAS as readonly string[]).includes(value);
}

/**
 * The request header `makefun status` sends on its agent home read, whose announcements it prints (cli/status.ts): a
 * makefun CLI (by its User-Agent) is drawn and recorded only on a read carrying it, so an account is never recorded as
 * shown an entry its client drops. Named as the feedback test's (contracts/feedback-invite.ts FEEDBACK_INVITE_SHOWN_HEADER).
 */
export const AGENTPAY_OFFER_SHOWN_HEADER = 'x-makefun-agentpay-offer';
/** That header's one value. */
export const AGENTPAY_OFFER_SHOWN = 'shown';

/**
 * The request header a makefun CLI sends on every call submitting something its signer just signed (a sign-in, a
 * register, a connect, an entry fee, a trade, a deposit, a claim, …; cli/signer-header.ts): which kind of signer signed.
 */
export const SIGNER_HEADER = 'x-makefun-signer';
/**
 * Its values: `agentpay` (the signer is the agentpay program: found on PATH, or a signer command whose program is named
 * agentpay), `keypair-file` (a solana-keygen keypair file), `command` (any other signer command).
 */
export const SIGNER_KINDS = ['agentpay', 'keypair-file', 'command'] as const;
export type SignerKind = (typeof SIGNER_KINDS)[number];

/** The kind a header value names (trimmed, any case), or null for anything else: an unknown value records nothing. */
export function signerKindOf(value: string | null | undefined): SignerKind | null {
  if (typeof value !== 'string') return null;
  const v = value.trim().toLowerCase();
  return (SIGNER_KINDS as readonly string[]).includes(v) ? (v as SignerKind) : null;
}

/** Each kind in plain words, for an admin. */
export const SIGNER_KIND_LABELS: Readonly<Record<SignerKind, string>> = { agentpay: 'agentpay', 'keypair-file': 'Keypair file', command: 'Other signer command' };

/** The test's setting's site_setting key. */
export const AGENTPAY_OFFER_SETTING_KEY = 'agentpay-offer-test';

/** The test's setting (site_setting agentpay-offer-test). */
export interface AgentpayOfferSetting {
  /** The offer arm's share of accounts, an integer 0 to 100; 0 turns the test off. */
  percent: number;
  /**
   * The link to agentpay's source (ruling 49): the offer says the wallet is open-source, so its words carry the link
   * (`Source: <url>`), and the test stays closed while there is none. Absent: none. Set on the day the source is public,
   * which is the owner's decision. One https URL (agentpaySourceIssue).
   */
  source?: string;
}

/** The setting read while the row is absent or invalid: a share of 0 and no source link, so the test is off until an admin saves both. */
export const AGENTPAY_OFFER_DEFAULTS: Readonly<AgentpayOfferSetting> = { percent: 0 };

/** The longest source link, in characters. */
export const AGENTPAY_SOURCE_MAX = 200;

/**
 * Why `url` cannot be the source link, or null when it can: one https URL (a host, nothing before it), at most
 * AGENTPAY_SOURCE_MAX characters, with no whitespace and no backtick (a surface may write it in a code span).
 */
export function agentpaySourceIssue(url: string): string | null {
  if (url === '') return 'it is empty: give the https URL of the source, or leave source out';
  if (url.length > AGENTPAY_SOURCE_MAX) return `it is ${url.length} characters: at most ${AGENTPAY_SOURCE_MAX}`;
  if (/\s/.test(url)) return 'it holds whitespace: the source link is one URL';
  if (url.includes('`')) return 'it holds a backtick: a surface may write the link inside one';
  if (!/^https:\/\/[^/?#@\s]+(?:[/?#]\S*)?$/i.test(url)) return 'it is not an https URL: the link starts https:// and names a host';
  return null;
}

/** The share the launch page's first save starts the test at. */
export const AGENTPAY_OFFER_START_PERCENT = 10;

/**
 * The five conditions the test runs under (ruling 48.3, and 49's fifth), every one needed: `share` the setting's percent
 * above 0, `source` the setting's source link set (the offer says open-source, so it shows the source), `install`
 * MAKEFUN_AGENTPAY_INSTALL set (the offer says how to get the wallet), `rails` this site serving its signed rails file
 * (a makefun runs a PATH agentpay for no other site), `words` the global MAKEFUN_AGENTPAY_WORDS off (with it on every
 * agent is told, and there is no control).
 */
export const AGENTPAY_OFFER_CONDITIONS = ['share', 'source', 'install', 'rails', 'words'] as const;
export type AgentpayOfferCondition = (typeof AGENTPAY_OFFER_CONDITIONS)[number];

/** Each condition as the admin card names it while it holds, and while it is closed. */
export const AGENTPAY_OFFER_CONDITION_WORDS: Readonly<Record<AgentpayOfferCondition, { open: string; closed: string }>> = {
  share: { open: 'The offer share is above 0', closed: 'The offer share is 0: save a share to start the test' },
  source: { open: 'The source link is set', closed: 'No source link: the offer says open-source, so it shows the source' },
  install: { open: 'MAKEFUN_AGENTPAY_INSTALL is set', closed: 'MAKEFUN_AGENTPAY_INSTALL is not set: the offer could not say how to get the wallet' },
  rails: { open: 'This site serves its signed rails file', closed: 'This site serves no signed rails file: makefun would run no agentpay found on PATH for it' },
  words: { open: 'MAKEFUN_AGENTPAY_WORDS is off', closed: 'MAKEFUN_AGENTPAY_WORDS is on: every agent is told already, so there is no control' },
};

/** Each condition's state: whether it holds. */
export type AgentpayOfferConditions = Readonly<Record<AgentpayOfferCondition, boolean>>;

/** The first condition that does not hold, in AGENTPAY_OFFER_CONDITIONS' order, or null when the test is on. */
export function closedConditionOf(c: AgentpayOfferConditions): AgentpayOfferCondition | null {
  return AGENTPAY_OFFER_CONDITIONS.find((k) => !c[k]) ?? null;
}

/** Early rule (ruling 48.9): the offer is called ahead at this many offered adopters while control has none. */
export const AGENTPAY_OFFER_EARLY_ADOPTERS = 3;
/** Fisher's exact test's two-sided level the offer is called ahead at. */
export const AGENTPAY_OFFER_ALPHA = 0.05;

/**
 * What a small test can say (ruling 48.10, from the research package 2026-11-25-one-decision-inside-make-fun-a-018def98,
 * evidence/power_tables.txt): the admin card prints these two lines under the numbers.
 */
export const AGENTPAY_OFFER_SIZE_LINES = [
  'At 10/90, 200 shown accounts see a 0%-to-10% take-up 61% of the time and 500 see it 97% of the time; a 3% take-up needs about 1,000, and the test cannot show the offer is harmless.',
  "Raise the share only after the current cohort's 14 days have closed.",
] as const;

/** The line every place the adoption numbers are shown carries (ruling 48.8). */
export const AGENTPAY_OFFER_SELF_REPORTED =
  'Adoption is the client\'s own word: a makefun says in a request header which kind of signer signed what it submits, and nothing proves it. No reward, ranking or gate may rest on it alone.';

/* ---- The readout (GET /api/admin/experiments/agentpay-offer) ---- */

/** A rate over an arm's shown accounts with its Wilson 95% interval; every field null with none shown. */
export interface AgentpayOfferRate {
  rate: number | null;
  low: number | null;
  high: number | null;
}

/** One arm's numbers: its shown accounts and, of those, the adopters and the two guardrails, inside the window. */
export interface AgentpayOfferArmView {
  arm: AgentpayOfferArm;
  /** Accounts with an exposure row in the arm (shown, or for control the read at which the offer would have been). */
  shown: number;
  /** Of those, the accounts whose first agentpay sighting fell after the first show and within the window. */
  adopted: number;
  adopted_rate: AgentpayOfferRate;
  /** Of those shown, the accounts that paid an entry fee inside the window (a guardrail). */
  fee_payers: number;
  fee_payer_rate: AgentpayOfferRate;
  /** Of those shown, the accounts that submitted an entry inside the window (a guardrail). */
  submitters: number;
  submitter_rate: AgentpayOfferRate;
  /** Of those shown, the accounts whose window has closed (14 days since the first show). */
  window_closed: number;
}

/** Who is ahead, if anyone, and on which rule: never a lift. */
export interface AgentpayOfferAhead {
  /** The arm called ahead, or null while neither is. */
  arm: AgentpayOfferArm | null;
  /** fisher: Fisher's exact test at AGENTPAY_OFFER_ALPHA two-sided; early_rule: three offered adopters against none. */
  rule: 'fisher' | 'early_rule' | null;
  /** Fisher's exact two-sided p of adopters by arm; null with an arm empty. */
  fisher_p: number | null;
}

/** The split's check: the arms' counts against the shares their accounts were drawn at (percent_at_first). */
export interface AgentpayOfferSplit {
  /** The expected count of each arm, summed from each exposure's percent_at_first. */
  expected: { control: number; offer: number };
  /** The chi-square's p, null while the smaller arm expects under SPLIT_MIN_EXPECTED (or none at all). */
  p: number | null;
  mismatch: boolean;
}

/** An offered account for a read by hand. */
export interface AgentpayOfferOfferedRow {
  user_id: string;
  handle: string | null;
  first_at: string;
  last_at: string;
  shows: number;
  first_via: AgentpayOfferVia;
  percent_at_first: number;
  /** Its first agentpay sighting, null with none. */
  agentpay_first_at: string | null;
  /** Whether it counts as adopting (that sighting after the first show and inside the window). */
  adopted: boolean;
}

export interface AgentpayOfferReadout {
  setting: AgentpayOfferSetting;
  /** Whether the test runs now (all five conditions hold). */
  on: boolean;
  /** Each condition, in AGENTPAY_OFFER_CONDITIONS' order, and whether it holds. */
  conditions: { condition: AgentpayOfferCondition; open: boolean; text: string }[];
  /** The first condition that does not hold, null while the test is on. */
  closed: AgentpayOfferCondition | null;
  window_days: number;
  /** The first exposure, ISO 8601; null with none. */
  first_show_at: string | null;
  arms: AgentpayOfferArmView[];
  ahead: AgentpayOfferAhead;
  split: AgentpayOfferSplit;
  /** Exposure rows whose stored arm is not what the draw gives at their percent_at_first (the audit): a count and the first few. */
  audit: { checked: number; wrong: number; wrong_user_ids: string[] };
  /** Accounts by the surface that first showed them an arm. */
  first_via: Record<AgentpayOfferVia, number>;
  /** Signer sightings: the accounts seen with each kind (any time), and those seen in the last day. */
  signers: { signer: SignerKind; accounts: number; last_day: number }[];
  /** The offered accounts, newest first (at most AGENTPAY_OFFER_LISTED). */
  offered: AgentpayOfferOfferedRow[];
  /** How many offered accounts there are in all. */
  offered_total: number;
}

/** The most offered accounts the readout lists. */
export const AGENTPAY_OFFER_LISTED = 200;

/** The test's admin routes, admins only (server/routes/admin/agentpay-offer.ts; server/api-types.ts registers them). */
export interface AdminAgentpayOfferRoutes {
  'GET /api/admin/experiments/agentpay-offer': { response: AgentpayOfferReadout };
  /**
   * Each field given replaces the setting's (percent an integer 0 to 100; source an https URL, agentpaySourceIssue's
   * rule, or null to clear it), the rest kept; at least one; any other value or field a 422, nothing written.
   */
  'POST /api/admin/experiments/agentpay-offer': { body: { percent?: number; source?: string | null }; response: AgentpayOfferReadout };
}
